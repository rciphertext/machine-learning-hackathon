
# coding: utf-8

# In[68]:

get_ipython().magic('matplotlib inline')

import warnings
warnings.filterwarnings('ignore')
warnings.filterwarnings('ignore', category=DeprecationWarning)

import pandas as pd
pd.options.display.max_columns = 100

from matplotlib import pyplot as plt
import numpy as np

import seaborn as sns
sns.set(rc={'figure.figsize':(12,9)})
import pylab as plot
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss,accuracy_score
import pickle


# In[69]:

df = pd.read_csv('train.csv')
df_test = pd.read_csv('test.csv')


# # DateTime Splitting

# In[70]:

df=pd.read_csv('train.csv', parse_dates=['DateTime'])

df_test=pd.read_csv('test.csv',parse_dates=['DateTime'])

df_test['Year'] = df_test['DateTime'].map(lambda x: x.year)
df_test['Month'] = df_test['DateTime'].map(lambda x: x.month)
df_test['Date'] = df_test['DateTime'].map(lambda x: x.day)
df_test['Hour'] = df_test['DateTime'].map(lambda x: x.hour)
df_test['Minute'] = df_test['DateTime'].map(lambda x: x.minute)

df['Year'] = df['DateTime'].map(lambda x: x.year)
df['Month'] = df['DateTime'].map(lambda x: x.month)
df['Date'] = df['DateTime'].map(lambda x: x.day)
df['Minute'] = df['DateTime'].map(lambda x: x.minute)
df['Hour'] = df['DateTime'].map(lambda x: x.hour)


# In[71]:

df=df.drop(labels=['DateTime'],axis=1)

#--------------------------------------------

df_test=df_test.drop(labels=['DateTime'],axis=1)


# In[72]:

#df['Hour']=df['Hour'].apply(lambda x:0 if x in(20,21,22,23,0,1,2,3,4,5) else (1 if x in(6,7,8,9,10) else (2 if x in(11,12,13,14,15) else 3)))


# # ANIMAL 
# 

# In[73]:

ax=sns.countplot(x=df['AnimalType'])


# In[74]:

df['AnimalType']=df['AnimalType'].apply(lambda x:1 if x in('Dog') else 0)

#---------------------------------------------------------------------

df_test['AnimalType']=df_test['AnimalType'].apply(lambda x:1 if x in('Dog') else 0)


# # Few Plots

# In[75]:

sns.countplot(x="OutcomeType",data=df)


# In[76]:

sns.countplot(x="SexuponOutcome",data=df)


# In[77]:

plt.figure(figsize=(12,4))
sns.countplot(x="AnimalType",hue="OutcomeType",data=df)


# In[78]:

df["SexuponOutcome"]=df["SexuponOutcome"].fillna("Unknown")

#-------------------------------------------------------------------


df_test["SexuponOutcome"]=df_test["SexuponOutcome"].fillna("Unknown")


# In[79]:

le = preprocessing.LabelEncoder()


# In[80]:

Cat=df['OutcomeType']
le_res=le.fit_transform(df['OutcomeType'])
y=pd.DataFrame(le_res)
y.columns=['OutcomeType']


# In[81]:

df=df.drop(labels=['AnimalID'],axis=1)


# convert_AgeuponOutcome_to_Years

# In[82]:

def convert_AgeuponOutcome_to_weeks(df):
    result = {}
    for k in df['AgeuponOutcome'].unique():
        if type(k) != type(""):
            result[k] = -1
        else:
            v1, v2 = k.split()
            if v2 in ["year", "years"]:
                result[k] = int(v1) * 1
            elif v2 in ["month", "months"]:
                result[k] = int(v1) / 12
            elif v2 in ["week", "weeks"]:
                result[k] = int(v1) / 52
            elif v2 in ["day", "days"]:
                result[k] = int(v1) / 365
                
    df['_AgeuponOutcome'] = df['AgeuponOutcome'].map(result).astype(float)
    df = df.drop('AgeuponOutcome', axis = 1)
                
    return df

df = convert_AgeuponOutcome_to_weeks(df)

#--------------------------------------------------------------------------------------

df_test = convert_AgeuponOutcome_to_weeks(df_test)


# In[83]:

sns.distplot(df._AgeuponOutcome,bins=20, kde=False)


# In[84]:

def calc_age_category(x):
    if x  <3: return 'young'
    if x  <5 and x>=3: return 'young adult'
    if x  <10 and x>=5: return 'adult'
    return 'old'
df['_AgeuponOutcome']=df._AgeuponOutcome.apply(calc_age_category)

#-----------------------------------------------------------------------------

df_test['_AgeuponOutcome']=df_test._AgeuponOutcome.apply(calc_age_category)


# In[85]:

fig = plt.figure(figsize=(10,6))
fig.add_subplot(1,1,1)
ax = sns.countplot(x=df['_AgeuponOutcome'],data=df)


# Breed Sepration

# In[86]:

x=df.Breed.str.contains(pat="Mix", case=True,regex=True)
Breed=pd.DataFrame(x)
le_res=le.fit_transform(Breed)
Breed=pd.DataFrame(le_res)
Breed.columns=['Breed']
df=df.drop(labels=['Breed'],axis=1)
df=pd.concat([Breed,df],axis=1)


# In[87]:

ax=sns.countplot(x=Cat,hue=df['Hour'])


# In[88]:

ax=sns.countplot(x=Cat,hue=df['Hour'])


# In[89]:

ax=sns.countplot(x=Cat,hue=df['Month'])


# In[90]:

ax=sns.countplot(x=Cat,hue=df['Year'])


# # LabelEncoding

# In[91]:

le_res=le.fit_transform(df['_AgeuponOutcome'])
_AgeuponOutcome=pd.DataFrame(le_res)


_AgeuponOutcome.columns=['_AgeuponOutcome']
df=df.drop(labels=['_AgeuponOutcome'],axis=1)
df=pd.concat([_AgeuponOutcome,df],axis=1)


#-------------------TEST SET----------------------------------------------------------------------

le_res_test=le.fit_transform(df_test['_AgeuponOutcome'])
_AgeuponOutcome_test=pd.DataFrame(le_res_test)


_AgeuponOutcome_test.columns=['_AgeuponOutcome']
df_test=df_test.drop(labels=['_AgeuponOutcome'],axis=1)
df_test=pd.concat([_AgeuponOutcome_test,df_test],axis=1)


# In[92]:

le_res=le.fit_transform(df['Breed'])
Breed=pd.DataFrame(le_res)


Breed.columns=['Breed']
df=df.drop(labels=['Breed'],axis=1)
df=pd.concat([Breed,df],axis=1)

#-------------------TEST SET----------------------------------------------------------------------

le_res_test=le.fit_transform(df_test['Breed'])
Breed_test=pd.DataFrame(le_res_test)

    
Breed_test.columns=['Breed']
df_test=df_test.drop(labels=['Breed'],axis=1)
df_test=pd.concat([Breed_test,df_test],axis=1)


# In[93]:

"""le_res=le.fit_transform(df['Mix'])
Mix=pd.DataFrame(le_res)


Mix.columns=['Mix']
df=df.drop(labels=['Mix'],axis=1)
df=pd.concat([Mix,df],axis=1)

#-------------------TEST SET----------------------------------------------------------------------


le_res_test=le.fit_transform(df_test['Mix'])
Mix_test=pd.DataFrame(le_res_test)


Mix_test.columns=['Mix']
df_test=df_test.drop(labels=['Mix'],axis=1)
df_test=pd.concat([Mix_test,df_test],axis=1)"""


# In[94]:


le_res=le.fit_transform(df['SexuponOutcome'])
SexuponOutcome=pd.DataFrame(le_res)
SexuponOutcome.columns=['SexuponOutcome']
df=df.drop(labels=['SexuponOutcome'],axis=1)
df=pd.concat([SexuponOutcome,df],axis=1)


#-------------------TEST SET----------------------------------------------------------------------


le_res_test=le.fit_transform(df_test['SexuponOutcome'])
SexuponOutcome_test=pd.DataFrame(le_res_test)
SexuponOutcome_test.columns=['SexuponOutcome']
df_test=df_test.drop(labels=['SexuponOutcome'],axis=1)
df_test=pd.concat([SexuponOutcome_test,df_test],axis=1)


# In[95]:

df['Month']=df['Month'].apply(lambda x : 0 if x <4 else (1 if x <8 else (2)))


# In[96]:

df['OutcomeType']=le.fit_transform(df['OutcomeType'])


# In[97]:

AA=df.corr()
AA


# In[98]:

sns.heatmap(AA,linewidths=2, cmap="coolwarm")


# # Dropping Unnecesary

# In[99]:

df=df.drop(labels=['OutcomeType'],axis=1)


# In[100]:

df=df.drop(labels=['OutcomeSubtype','Color','Name'],axis=1)

#------------------------------------------------------------

df_test=df_test.drop(labels=['Color','Name'],axis=1)


# # Train Test Split

# In[101]:

X=df


# In[102]:

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)


# # Importance Of Features

# In[103]:

from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
classifier = LogisticRegression(penalty='l2',random_state = 0,class_weight='balanced',multi_class='multinomial', 
                                solver='lbfgs',n_jobs=-1)
selector = RFE(classifier, 5, step=1)
selector = selector.fit(X, y)
selector.support_


# In[104]:

selector.ranking_


# In[105]:

from sklearn.feature_selection import RFE
from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier(max_depth=4,n_estimators =20,criterion = 'entropy',random_state = 0)
selector = RFE(clf, 5, step=1)
selector = selector.fit(X, y)
selector.support_


# In[106]:

selector.ranking_


# In[107]:

from xgboost import XGBClassifier
import xgboost as xgb
from sklearn.feature_selection import RFE
model = xgb.XGBClassifier(objective='multi:softprob')
selector = RFE(model, 5, step=1)
selector = selector.fit(X, y)
selector.support_


# In[108]:

selector.ranking_


# # Logistic Regression

# In[109]:

from sklearn.linear_model import LogisticRegression
#weight={Address:3,District:3,X:1,Day:2}
#weight={LARCENY/THEFT:35}
#classifier = LogisticRegression(penalty='l2',random_state = 0,class_weight='balanced',multi_class='multinomial', solver='lbfgs',n_jobs=-1)
#classifier.fit(X_train,y_train)


# In[110]:

filename = 'logistic_model.sav'
#pickle.dump(classifier, open(filename, 'wb'))


# In[111]:

loaded_model = pickle.load(open(filename, 'rb'))


# In[112]:

loaded_model.fit(X_train,y_train)


# In[113]:

y_pred=loaded_model.predict_proba(X_test)


# In[114]:

#y_pred=classifier.predict_proba(X_test)


# In[115]:

ll = log_loss(y_test,y_pred)
ll


# # XGBOOST

# In[116]:

from xgboost import XGBClassifier
import xgboost as xgb
#model = xgb.XGBClassifier(objective='multi:softprob')
#model.fit(X_train, y_train)


# In[117]:

filename = 'xgboost_model.sav'
#pickle.dump(model, open(filename, 'wb'))


# In[118]:

loaded_model = pickle.load(open(filename, 'rb'))
loaded_model.fit(X_train, y_train)


# In[119]:

y_pred=loaded_model.predict_proba(X_test)


# In[120]:

ll = log_loss(y_test,y_pred)
ll


# In[121]:

#y_pred=model.predict_proba(X_test)


# In[122]:

xgb.plot_importance(loaded_model)


# # XGBOOST PARAMETER TUNNING

# In[123]:

HYPER_PARAMS = { 
 'learning_rate': 0.20,
 'n_estimators':100,
 'max_depth': 5,
 'subsample': 0.7,
 'colsample_bytree': 0.9,
 'max_delta_step': 1,
 'objective': 'multi:softmax',
 'nthread': 1,
 }

#model = xgb.XGBClassifier(**HYPER_PARAMS)
#model.fit(X_train,y_train)


# In[124]:

filename = 'xgboostparam_model.sav'
#pickle.dump(model, open(filename, 'wb'))


# In[125]:

loaded_model = pickle.load(open(filename, 'rb'))
loaded_model.fit(X_train,y_train)


# In[126]:

y_pred=loaded_model.predict_proba(X_test)


# In[127]:

#y_pred=model.predict_proba(X_test)


# In[128]:

print (log_loss(y_test,y_pred));


# # Naive Bayes 

# In[129]:

from sklearn.feature_selection import RFE
from sklearn.naive_bayes import GaussianNB
#nv = GaussianNB()
#nv.fit(X_train,y_train)



# In[130]:

filename = 'naive_model.sav'
#pickle.dump(nv, open(filename, 'wb'))


# In[131]:

loaded_model = pickle.load(open(filename, 'rb'))
loaded_model.fit(X_train,y_train)


# In[132]:

y_pred=loaded_model.predict_proba(X_test)


# In[133]:

ll = log_loss(y_test,y_pred)
ll


# In[134]:

#y_pred=nv.predict_proba(X_test)
#print (log_loss(y_test,y_pred));


# #  Random Forest

# In[135]:

from sklearn.ensemble import RandomForestClassifier
#clf = RandomForestClassifier(max_depth=7,n_estimators =20,criterion = 'entropy',random_state = 0)
#clf.fit(X_train,y_train)


# In[136]:

filename = 'random_model.sav'
#pickle.dump(clf, open(filename, 'wb'))


# In[137]:

loaded_model = pickle.load(open(filename, 'rb'))
y_pred=loaded_model.predict_proba(X_test)


# In[138]:

print (log_loss(y_test,y_pred));

